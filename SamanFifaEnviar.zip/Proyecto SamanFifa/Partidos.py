class Partidos:
    def __init__(self, equipo1, equipo2, estadio, golesequipo1, golesequipo2, goleadoresequipo1, goleadoresequipo2, precioentradageneral, precioentradaVIP):
        self.equipo1 = equipo1
        self.equipo2 = equipo2
        self.estadio = estadio
        self.golesequipo1 = golesequipo1
        self.golesequipo2 = golesequipo2
        self.goleadoresequipo1 = goleadoresequipo1
        self.goleadoresequipo2 = goleadoresequipo2
        self.precioentradageneral = precioentradageneral
        self.precioentradaVIP = precioentradaVIP