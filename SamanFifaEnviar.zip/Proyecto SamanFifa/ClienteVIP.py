class ClienteVIP:
    def __init__(self, gasto, productoscomprados):
        self.gasto = gasto
        self.productoscomprados = productoscomprados
