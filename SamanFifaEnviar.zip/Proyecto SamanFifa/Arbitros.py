from SamanFifa import SamanFifa

class Arbitros(SamanFifa):
    def __init__(self, nombre):
        super().__init__(nombre)
        