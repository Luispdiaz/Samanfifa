class SamanFifa:
    def __init__(self, nombre):
        self.nombre = nombre
        
